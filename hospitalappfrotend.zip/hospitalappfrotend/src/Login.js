import React, { useState } from 'react';
import axios from 'axios';

import 'bootstrap/dist/css/bootstrap.min.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [UserType, setUserType] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('https://localhost:44318/api/Login', { username, password,UserType });
      console.log(response.data);
    } catch (err) {
      console.log(err);
      setErrorMessage('Invalid username or password');
    }
  };

  return (
    <div className="bg-light" style={{ height: '100vh' }}>
      <div className="container d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
        <div className="card p-4 border-secondary">
          <h1 className="text-center mb-4">Log In</h1>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input
                type="text"
                className="form-control"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                className="form-control"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="UserType">UserType</label>
              <input
                type="text"
                className="form-control"
                id="UserType"
                value={UserType}
                onChange={(e) => setUserType(e.target.value)}
              />
            </div>
            {errorMessage && <p className="text-danger">{errorMessage}</p>}
            <button type="submit" className="btn btn-primary">Log In</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
