import React, { useState, useEffect } from "react";
import axios from "axios";

function Doctor() {
  const [doctors, setDoctors] = useState([]);

  // Fetch all doctors from the API
  useEffect(() => {
    axios
      .get("https://localhost:44318/api/Doctor/GetDoctor")
      .then((response) => {
        setDoctors(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  // Add a new doctor to the API
  const addDoctor = (newDoctor) => {
    axios
      .post("https://localhost:44318/api/Doctor", newDoctor)
      .then((response) => {
        setDoctors([...doctors, response.data]);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Delete a doctor from the API
  const deleteDoctor = (doctorId) => {
    axios
      .delete(`https://localhost:44318/api/Doctor/Delete/${doctorId}`)
      .then((response) => {
        setDoctors(doctors.filter((d) => d.doctorId !== doctorId));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="container">
      <h1>Doctors</h1>
      <ul className="list-group">
        {doctors.map((doctor) => (
          <li key={doctor.doctorId} className="list-group-item d-flex justify-content-between align-items-center">
            <span>{doctor.doctorName} ({doctor.specialty})</span>
            <button className="btn btn-danger" onClick={() => deleteDoctor(doctor.doctorId)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const newDoctor = {
            doctorName: e.target.doctorName.value,
            specialty: e.target.specialty.value,
            email: e.target.email.value,
          };
          addDoctor(newDoctor);
        }}
      >
        <h2>Add New Doctor</h2>
        <div className="form-group">
          <label htmlFor="doctorId">ID:</label>
          <input type="number" id="doctorId" className="form-control" />
        </div>
        <div className="form-group">
          <label htmlFor="doctorName">Name:</label>
          <input type="text" id="doctorName" className="form-control" />
        </div>
        <div className="form-group">
          <label htmlFor="specialty">Specialty:</label>
          <input type="text" id="specialty" className="form-control" />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" className="form-control" />
        </div>
        <button type="submit" className="btn btn-primary">Add Doctor</button>
      </form>
    </div>
  );
}

export default Doctor;
