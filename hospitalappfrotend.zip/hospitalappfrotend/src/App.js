import './App.css';
import React from "react";
import Signup from './Signup';
import Login from './Login';
import Patient from "./Patient";
import Doctor from './Doctor';
import Appointment from './Appointment';
import AboutUs from './AboutUs';
import { BrowserRouter as Router, Switch, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <Routes>
            <Route path="/Signup" element={<Signup />}></Route>
            <Route path="/Login" element={<Login />}></Route>
            <Route path="/Patient" element={<Patient />}></Route>
            <Route path="/Doctor" element={<Doctor />}></Route>
            <Route path="/Appointment" element={<Appointment />}></Route>
            <Route path="/AboutUs" element={<AboutUs />}></Route>




    </Routes>
  );
}

export default App;
