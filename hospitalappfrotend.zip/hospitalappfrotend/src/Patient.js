import React, { useState, useEffect } from "react";
import axios from "axios";
import { useHistory } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css"; 

function Patient() {
  const [patients, setPatients] = useState([]);

  // Fetch all patients from the API
  useEffect(() => {
    axios
      .get("https://localhost:44318/api/Patient/GetPatient")
      .then((response) => {
        setPatients(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  // Add a new patient to the API
  const addPatient = (newPatient) => {
    axios
      .post("https://localhost:44318/api/Patient", newPatient)
      .then((response) => {
        setPatients([...patients, response.data]);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Delete a patient from the API
  const deletePatient = (patientId) => {
    axios
      .delete(`https://localhost:44318/api/Patient/Delete/${patientId}`)
      .then((response) => {
        setPatients(patients.filter((p) => p.patientId !== patientId));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="container">
      <h1 className="mt-5">Patients</h1>
      <ul className="list-group">
        {patients.map((patient) => (
          <li key={patient.patientId} className="list-group-item">
            {patient.patientName} ({patient.dob})
            <button
              className="btn btn-danger btn-sm float-end"
              onClick={() => deletePatient(patient.patientId)}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
      <form
        className="mt-5"
        onSubmit={(e) => {
          e.preventDefault();
          const newPatient = {
            patientName: e.target.patientName.value,
            dob: e.target.dob.value,
            address: e.target.address.value,
            phoneNumber: e.target.phoneNumber.value,
          };
          addPatient(newPatient);
        }}
      >
        <h2>Add New Patient</h2>
        <div className="mb-3">
          <label htmlFor="patientName" className="form-label">
            Name:
          </label>
          <input type="text" className="form-control" id="patientName" />
        </div>
        <div className="mb-3">
          <label htmlFor="dob" className="form-label">
            Date of Birth:
          </label>
          <input type="date" className="form-control" id="dob" />
        </div>
        <div className="mb-3">
          <label htmlFor="address" className="form-label">
            Address:
          </label>
          <input type="text" className="form-control" id="address" />
        </div>
        <div className="mb-3">
          <label htmlFor="phoneNumber" className="form-label">
            Phone Number:
          </label>
          <input type="text" className="form-control" id="phoneNumber" />
        </div>
        <button type="submit" className="btn btn-primary">
          Add Patient
        </button>
        
      </form>
    </div>
  );
}

export default Patient;
