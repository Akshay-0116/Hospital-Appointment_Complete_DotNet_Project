import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Appointment = () => {
  const [appointments, setAppointments] = useState([]);
  const [appointmentId, setAppointmentId] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [appointmentReason, setAppointmentReason] = useState('');
  const [patientId, setPatientId] = useState('');
  const [doctorId, setDoctorId] = useState('');

  useEffect(() => {
    getAppointments();
  }, []);

  const getAppointments = async () => {
    try {
      const res = await axios.get('https://localhost:44318/api/Appointment/GetAppointment');
      setAppointments(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newAppointment = {
      appointmentId,
      appointmentDate,
      appointmentReason,
      patientId,
      doctorId,
    };

    try {
      await axios.post('https://localhost:44318/api/Appointment', newAppointment);
      getAppointments();
    } catch (err) {
      console.log(err);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://localhost:44318/api/Appointment/Delete/${id}`);
      getAppointments();
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="container">
      <h1 className="text-center">Appointments</h1>
      <form onSubmit={handleSubmit}>
        <div className="row mb-3">
          <div className="col">
            <input
              type="number"
              className="form-control"
              placeholder="Appointment Id"
              value={appointmentId}
              onChange={(e) => setAppointmentId(e.target.value)}
            />
          </div>
          <div className="col">
            <input
              type="date"
              className="form-control"
              placeholder="Appointment Date"
              value={appointmentDate}
              onChange={(e) => setAppointmentDate(e.target.value)}
            />
          </div>
        </div>
        <div className="row mb-3">
          <div className="col">
            <input
              type="text"
              className="form-control"
              placeholder="Appointment Reason"
              value={appointmentReason}
              onChange={(e) => setAppointmentReason(e.target.value)}
            />
          </div>
          <div className="col">
            <input
              type="number"
              className="form-control"
              placeholder="Patient Id"
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
            />
          </div>
          <div className="col">
            <input
              type="number"
              className="form-control"
              placeholder="Doctor Id"
              value={doctorId}
              onChange={(e) => setDoctorId(e.target.value)}
            />
          </div>
          <div className="col-auto">
            <button type="submit" className="btn btn-primary">Add Appointment</button>
          </div>
        </div>
      </form>
      <table className="table table-striped table-hover">
        <thead>
          <tr>
            <th>Appointment Id</th>
            <th>Appointment Date</th>
            <th>Appointment Reason</th>
            <th>Patient Id</th>
            <th>Doctor Id</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map
((appointment) => (
            <tr key={appointment.appointmentId}>
              <td>{appointment.appointmentId}</td>
              <td>{appointment.appointmentDate}</td>
              <td>{appointment.appointmentReason}</td>
              <td>{appointment.patientId}</td>
              <td>{appointment.doctorId}</td>
              <td>
                <button onClick={() => handleDelete(appointment.appointmentId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Appointment;
