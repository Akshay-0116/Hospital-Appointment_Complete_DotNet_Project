import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import "bootstrap/dist/css/bootstrap.min.css"; 

const AboutUs = () => {
  return (
    <div>
      <Container>
        <Row className="bg-light p-3 border rounded mb-3">
          <Col md={8}>
            <h1>About Us</h1>
            <p>Welcome to our hospital appointment website! We are dedicated to providing high-quality medical care to our patients and making the appointment booking process as easy and convenient as possible.</p>
            <p>Our team of experienced doctors and healthcare professionals are committed to providing compassionate and personalized care to each patient, and we strive to maintain a warm and welcoming environment for everyone who walks through our doors.</p>
            <p><img src={process.env.PUBLIC_URL + '/OIP (1).jpeg'} alt="Patient" height="40" /> 30+ Professional Doctors</p>
            <p><img src={process.env.PUBLIC_URL + '/OIP (1).jpeg'} alt="Patient" height="40" /> 10000+ Happy Patient..</p>
          </Col>
        </Row>
        <Row className="bg-light p-3 border rounded">
          <Col md={8}>
            <h3>Contact Us</h3>
            <p>123 Main Street</p>
            <p>Coimbatore, CB 100 001</p>
            <p>Phone: (555) 555-5555</p>
            <p>Email: info@hospitalappointment.com</p>
                        
          </Col>
        </Row>
        <p className="bg-info border border-danger text-center" style={{ marginTop: '5px', padding: '10px', fontFamily:'monospace' }}>Thank you for choosing our hospital for your healthcare needs. We look forward to serving you and your family.</p>

        <Row className="mt-2">
          <Col className="d-flex justify-content-center">
            <img src={process.env.PUBLIC_URL + '/OIP.jpeg'} alt="Verified" height="60" />
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default AboutUs;
