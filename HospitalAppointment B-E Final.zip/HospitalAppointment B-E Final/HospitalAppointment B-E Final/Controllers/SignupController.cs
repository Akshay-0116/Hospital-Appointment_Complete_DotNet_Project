﻿using HospitalAppointment_B_E_Final.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace HospitalAppointment_B_E_Final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SignupController : ControllerBase
    {
        private readonly HospitalAppointmentFinalContext _context;
        private readonly ILogger<SignupController> _logger;

        public SignupController(HospitalAppointmentFinalContext context, ILogger<SignupController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet("GetSignup")]
        public IActionResult GetSignup()
        {
            try
            {
                List<SignupPage> signup = _context.SignupPages.ToList();
                return Ok(signup);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] SignupPage signup)
        {
            try
            {
                _context.SignupPages.Add(signup);
                _context.SaveChanges();
                _logger.LogInformation("New user added with username: {0}", signup.Username);
                return Created("user Added", signup.Username);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("CheckUserNameExist")]
        public IActionResult CheckUserNameExist([FromBody] SignupPage signup)
        {
            try
            {
                var user = _context.SignupPages.FirstOrDefault(u => u.Username == signup.Username);
                if (user != null)
                {
                    return Ok(1);
                }
                else
                {
                    return NotFound(0);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}