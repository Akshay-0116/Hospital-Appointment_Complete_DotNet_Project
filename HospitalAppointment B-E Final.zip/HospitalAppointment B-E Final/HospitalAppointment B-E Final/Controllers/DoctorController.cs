﻿using HospitalAppointment_B_E_Final.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;
using System;

namespace HospitalAppointment_B_E_Final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        private readonly HospitalAppointmentFinalContext _context;
        private readonly ILogger<DoctorController> _logger;
        public DoctorController(HospitalAppointmentFinalContext context, ILogger<DoctorController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet("GetDoctor")]
        public IActionResult GetDoctor()
        {
            try
            {
                List<Doctor> D = _context.Doctors.ToList();
                _logger.LogInformation("These are the Doctors List");

                return Ok(D);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while getting the doctors list");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while getting the doctors list");
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] Doctor D)
        {
            try
            {
                _context.Doctors.Add(D);
                _context.SaveChanges();
                _logger.LogInformation("Doctor Added");
                return Created("Doctor Added", D);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding a doctor");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while adding a doctor");
            }
        }

        [HttpDelete("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                Doctor doctor = _context.Doctors.Find(id);
                if (doctor == null)
                {
                    return NotFound();
                }
                _context.Doctors.Remove(doctor);
                _context.SaveChanges();
                _logger.LogInformation("Doctor with id {id} deleted", id);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while deleting the doctor with id {id}");
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the doctor with id {id}");
            }
        }
    }
}