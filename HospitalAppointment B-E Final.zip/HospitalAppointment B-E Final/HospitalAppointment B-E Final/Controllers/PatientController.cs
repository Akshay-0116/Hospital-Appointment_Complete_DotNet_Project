﻿using HospitalAppointment_B_E_Final.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;
using System;

namespace HospitalAppointment_B_E_Final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly ILogger<PatientController> _logger;
        private readonly HospitalAppointmentFinalContext _context;

        public PatientController(HospitalAppointmentFinalContext context, ILogger<PatientController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet("GetPatient")]
        public IActionResult GetPatient()
        {
            try
            {
                List<Patient> patients = _context.Patients.ToList();
                _logger.LogInformation("Patients list retrieved successfully");
                return Ok(patients);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving patients");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving patients");
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] Patient patient)
        {
            try
            {
                _context.Patients.Add(patient);
                _context.SaveChanges();
                _logger.LogInformation("New patient added with the name {Name}", patient.PatientName);
                return Created("Patient Added", patient);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding the patient");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while adding the patient");
            }
        }

        [HttpDelete("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                Patient patient = _context.Patients.Find(id);
                if (patient == null)
                {
                    _logger.LogInformation("Patient with id {id} not found", id);
                    return NotFound();
                }
                _context.Patients.Remove(patient);
                _context.SaveChanges();
                _logger.LogInformation("Patient with id {id} deleted successfully", id);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the patient with id {id}", id);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while deleting the patient");
            }
        }
    }
}
