﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using HospitalAppointment_B_E_Final.Models;
using Microsoft.Extensions.Logging;

namespace HospitalAppointment_B_E_Final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly HospitalAppointmentFinalContext _context;
        private readonly ILogger<LoginController> _logger;

        public LoginController(HospitalAppointmentFinalContext context, ILogger<LoginController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult> Get()
        {
            try
            {
                var loginPages = await _context.LoginPages.ToListAsync();

                return Ok(loginPages);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching login pages");

                return StatusCode(500, "An error occurred while fetching login pages");
            }
        }


        [HttpPost]
        public async Task<ActionResult> Post(LoginPage loginPage)
        {
            try
            {
                var existingLoginPage = await _context.LoginPages.FirstOrDefaultAsync(lp => lp.Username == loginPage.Username);

                if (existingLoginPage != null)
                {
                    return Conflict();
                }

                _context.LoginPages.Add(loginPage);
                await _context.SaveChangesAsync();

                _logger.LogInformation("LoginPage created with username {Username}", loginPage.Username);
                return CreatedAtAction(nameof(Get), new { id = loginPage.Username }, loginPage);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while creating a login page");

                return StatusCode(500, "An error occurred while creating a login page");
            }
        }
    }
}

