﻿using HospitalAppointment_B_E_Final.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;
using System;

namespace HospitalAppointment_B_E_Final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly HospitalAppointmentFinalContext _context;
        private readonly ILogger<AppointmentController> _logger;

        public AppointmentController(HospitalAppointmentFinalContext context, ILogger<AppointmentController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet("GetAppointment")]
        public IActionResult GetAppointment()
        {
            try
            {
                List<Appointment> appointments = _context.Appointments.ToList();
                _logger.LogInformation("List of appointments retrieved successfully");
                return Ok(appointments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving appointments");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while retrieving appointments");
            }
        }

        [HttpPost]
        public IActionResult Post([FromBody] Appointment appointment)
        {
            try
            {
                _context.Appointments.Add(appointment);
                _context.SaveChanges();
                _logger.LogInformation("Appointment added successfully");
                return Created("Appointment Added", appointment);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while adding the appointment");
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while adding the appointment");
            }
        }

        [HttpDelete("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                Appointment appointment = _context.Appointments.Find(id);
                if (appointment == null)
                {
                    _logger.LogInformation("Appointment with id {id} not found", id);
                    return NotFound();
                }
                _context.Appointments.Remove(appointment);
                _context.SaveChanges();
                _logger.LogInformation("Appointment with id {id} deleted successfully", id);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while deleting the appointment with id {id}", id);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while deleting the appointment");
            }
        }
    }
}
