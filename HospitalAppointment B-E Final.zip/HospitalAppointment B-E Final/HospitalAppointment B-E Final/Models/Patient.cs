﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalAppointment_B_E_Final.Models
{
    public partial class Patient
    {
        public Patient()
        {
            Appointments = new HashSet<Appointment>();
        }

        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public DateTime Dob { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }

        public virtual ICollection<Appointment> Appointments { get; set; }
        public int Id { get; set; }
    }
}
