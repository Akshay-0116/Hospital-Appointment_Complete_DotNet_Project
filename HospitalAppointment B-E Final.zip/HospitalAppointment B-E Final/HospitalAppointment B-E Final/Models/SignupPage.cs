﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalAppointment_B_E_Final.Models
{
    public partial class SignupPage
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}
