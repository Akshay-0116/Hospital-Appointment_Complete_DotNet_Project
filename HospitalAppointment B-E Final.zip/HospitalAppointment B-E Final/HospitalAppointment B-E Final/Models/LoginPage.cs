﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HospitalAppointment_B_E_Final.Models
{
    public partial class LoginPage
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string UserType { get; set; }
    }
}
