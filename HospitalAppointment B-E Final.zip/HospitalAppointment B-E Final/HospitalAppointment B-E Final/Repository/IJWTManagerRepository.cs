﻿namespace HospitalAppointment_B_E_Final.Repository
{
    public interface IJWTManagerRepository
    {
        string AuthenticateSignupPage(string Username, string password, string ConfirmPassword);
       
    }
}
