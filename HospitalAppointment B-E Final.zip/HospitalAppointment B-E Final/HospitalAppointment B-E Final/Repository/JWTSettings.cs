﻿namespace HospitalAppointment_B_E_Final.Repository
{
    public class JWTSettings
    {
        public string Key { get; set; }
    }
}
