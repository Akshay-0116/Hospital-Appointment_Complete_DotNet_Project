﻿using HospitalAppointment_B_E_Final.Models;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace HospitalAppointment_B_E_Final.Repository
{
    public class JWTManagerRepository: IJWTManagerRepository
    {

        private readonly HospitalAppointmentFinalContext repo;
        private readonly JWTSettings jWTSettings;
        public JWTManagerRepository(HospitalAppointmentFinalContext repo, IOptions<JWTSettings> jWTSettings)
        {
            this.repo = repo;
            this.jWTSettings = jWTSettings.Value;
        }
        public string AuthenticateSignupPage(string Username, string password, string ConfirmPassword)
        {

            List<SignupPage> SignupPageRecords = repo.SignupPages.ToList();
            var SignupPage = SignupPageRecords.FirstOrDefault(x => x.Username == Username && x.Password == password && x.ConfirmPassword == ConfirmPassword );
            if (SignupPage == null)
            {
                return null;
            }
            // Else we generate JSON Web Token
            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenKey = Encoding.UTF8.GetBytes(jWTSettings.Key);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
              {
             new Claim(SignupPage.Password, SignupPage.Password.ToString()),
             new Claim(ClaimTypes.Version,"V3.1")
              }),
                Expires = DateTime.UtcNow.AddMinutes(30),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(tokenKey), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var GetToken = tokenHandler.WriteToken(token);


            return GetToken;
        }

    }
}