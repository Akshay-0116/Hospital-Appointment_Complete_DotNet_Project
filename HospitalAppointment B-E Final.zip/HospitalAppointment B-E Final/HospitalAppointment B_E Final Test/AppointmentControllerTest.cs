﻿using HospitalAppointment_B_E_Final.Controllers;
using HospitalAppointment_B_E_Final.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HospitalAppointment_B_E_Final.Tests
{
    [TestFixture]
    public class AppointmentControllerTests
    {
        private HospitalAppointmentFinalContext _context;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<HospitalAppointmentFinalContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;
            _context = new HospitalAppointmentFinalContext(options);
        }

        [Test]
        public void GetAppointment_ReturnsListOfAppointments()
        {
            // Arrange
            var controller = new AppointmentController(_context, null);

            // Act
            var result = controller.GetAppointment();

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.IsInstanceOf<List<Appointment>>(okResult.Value);
            var appointments = okResult.Value as List<Appointment>;
            Assert.That(appointments.Count, Is.EqualTo(5));
        }

        [TearDown]
        public void TearDown()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }
    }
}