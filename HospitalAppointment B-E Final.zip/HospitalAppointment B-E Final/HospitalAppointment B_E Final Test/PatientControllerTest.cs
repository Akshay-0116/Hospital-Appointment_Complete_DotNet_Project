﻿using HospitalAppointment_B_E_Final.Controllers;
using HospitalAppointment_B_E_Final.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HospitalAppointment_B_E_Final.Test
{
    [TestFixture]
    public class PatientControllerTest
    {
        private ILogger<PatientController> _logger;
        private HospitalAppointmentFinalContext _context;

        [SetUp]
        public void Setup()
        {
            _context = new HospitalAppointmentFinalContext();
            _logger = new Logger<PatientController>(new LoggerFactory());
        }

        [Test]
        public void TestGetPatient()
        {
            // Arrange
            var controller = new PatientController(_context, _logger);
            int expectedCount = _context.Patients.Count();

            // Act
            var result = controller.GetPatient() as OkObjectResult;
            var patients = result.Value as List<Patient>;

            // Assert
            Assert.IsNotNull(result);
            Assert.That(result.StatusCode, Is.EqualTo(200));
            Assert.That(patients.Count, Is.EqualTo(expectedCount));
        }

        [Test]
        public void TestPost()
        {
            // Arrange
            var controller = new PatientController(_context, _logger);
            var patient = new Patient
            {
                PatientId = 0,
                PatientName = "John Doe",
                Dob = new DateTime(1985, 1, 1),
                Address = "123 Main St",
                PhoneNumber = "555-555-1212"
            };

            // Act
            var result = controller.Post(patient) as CreatedResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.That(result.StatusCode, Is.EqualTo(201));
            Assert.That(result.Value, Is.InstanceOf<Patient>());
            Assert.That(result.Value, Is.EqualTo(patient));
            Assert.That(_context.Patients.Count(), Is.EqualTo(1));
        }

        [Test]
        public void TestDelete()
        {
            // Arrange
            var controller = new PatientController(_context, _logger);
            var patient = new Patient
            {
                PatientId= 0,
                PatientName = "John Doe",
                Dob = new DateTime(1985, 1, 1),
                Address = "123 Main St",
                PhoneNumber = "555-555-1212"
            };
            _context.Patients.Add(patient);
            _context.SaveChanges();

            // Act
            var result = controller.Delete(patient.PatientId) as OkResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.That(result.StatusCode, Is.EqualTo(200));
            Assert.That(_context.Patients.Count(), Is.EqualTo(0));
        }
    }
}
